
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package puzzle;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * @author AnhTu
 */
public class PuzzleMap {

    Puzzle p;
    private JPanel pnLayout;
    private JLabel lbTime;
    private JLabel lbCount;

    private ArrayList<JButton> arrBtn;
    private int numMove = 0;
    private Timer t;

    private boolean isGameStart=false;

    public PuzzleMap(JPanel pnLayout, JLabel lbTime, JLabel lbCount) {
        this.pnLayout = pnLayout;
        this.lbTime = lbTime;
        this.lbCount = lbCount;
    }

    private void initMoveCount() {
        numMove = 0;
        p.lbCount.setText("0");
    }

    public void initTime() {
        p.lbTime.setText("0");
        t = new Timer(1000, new ActionListener() {
            int second = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                second++;
                p.lbTime.setText(String.valueOf(second));
            }
        });
        t.start();
    }

    private void init() {
        this.initMoveCount();
        this.initTime();
        this.initMatrix();
        isGameStart = true;
    }

    private boolean checkMove(JButton btn, int size) {
        if (btn.getText().equals("")) {
            return false;
        }
        int startCol = 0;
        int startRow = 0;
        int desCol = 0;
        int desRow = 0;
        // get vi tri
        for (int i = 0; i < arrBtn.size(); i++) {
            if (arrBtn.get(i).getText().equals(btn.getText())) {
                startCol = i % size;
                startRow = i / size;
            }
            if (arrBtn.get(i).getText().equals("")) {
                desCol = i % size;
                desRow = i / size;
            }
        }
        if (startCol == desCol) {
            if (startRow == (desRow - 1) || startRow == (desRow + 1)) {
                return true; // move up or down
            }
        }
        if (startRow == desRow) {
            if (startCol == (desCol - 1) || startCol == (desCol + 1)) {
                return true; // move left or right
            }
        }
        return false;
    }
//count button move

    private void moveBtn(JButton btn) { // move Button
        for (int i = 0; i < arrBtn.size(); i++) {
            if (arrBtn.get(i).getText().equals("")) {
                arrBtn.get(i).setText(btn.getText());
                break;
            }
        }
        btn.setText("");
        numMove++;
        lbTime.setText(String.valueOf(numMove));
    }

    private ArrayList randomMatrix(int num) { // return a random array
        ArrayList<String> data = new ArrayList<>();
        ArrayList<Integer> d = new ArrayList<>();
        for (int i = 0; i < num; i++) {
            d.add(i + 1);

        }
//        do {
//            Collections.shuffle(d);
//            s = 0;
//            for (int i = 0; i < num; i++) {
//                System.out.println("" + d.get(i));
//                for (int j = i + 1; j < num; j++) {
//                    if (d.get(i) > d.get(j)) {
//                        dem++;
//                    }
//
//                }
//                s = s + dem;
//                dem = 0;
//            }
//
//        } while (s > 0 && s % 2 == 1);
        data.add("");
        for (int i = 0; i < num; i++) {

            data.add(String.valueOf(d.get(i)));
        }
        Collections.shuffle(data);
        return data;
    }

    public void initButon(int size) { // khởi tạo button ban đầu
        arrBtn = new ArrayList<>();
        ArrayList<String> data = new ArrayList<>();
        int num = size * size - 1;
        data = randomMatrix(num);
        pnLayout.removeAll();
        pnLayout.setLayout(new GridLayout(size, size, 0, 0));
        for (int i = 0; i < data.size(); i++) {
            JButton btn = new JButton(data.get(i));
            pnLayout.add(btn);
            arrBtn.add(btn);
            btn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (isGameStart) {
                        if (checkMove(btn, size)) {
                            moveBtn(btn);
                            if (checkWin()) {
                                isGameStart = false;
                                t.stop();
                                JOptionPane.showMessageDialog(null, "You Won!");
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Press New Game to start");
                    }
                }
            });

        }

    }

    private boolean checkWin() {
        ArrayList<String> btnText = new ArrayList<>();
        for (int i = 0; i < arrBtn.size() - 1; i++) {
            btnText.add(arrBtn.get(i).getText());
        }
        for (int i = 0; i < btnText.size(); i++) {
            for (int j = i; j < btnText.size(); j++) {
                if (btnText.get(j).equals("")) {
                    return false;
                }
                if (Integer.parseInt(btnText.get(j)) < Integer.parseInt(btnText.get(i))) {
                    return false;
                }
            }
        }
        return true;
    }

    // set panel
    private void setWindowsSize(int num) {
        int heightButton = 60;
        int widthButton = 60;

        //pnLayout.setSize(new Dimension(widthButton*num, heightButton*num));
        pnLayout.setPreferredSize(new Dimension(widthButton * num, heightButton * num));
//        pnLayout.setMaximumSize(new Dimension(widthButton * num, heightButton * num));
//        pnLayout.setMinimumSize(new Dimension(widthButton * num, heightButton * num));

        //pnLayout.setBackground(Color.red);
        p.setResizable(false);
        p.pack();

        System.out.println(pnLayout.getSize());
    }

    public void initMatrix() {
        String s = p.cmbSize.getSelectedItem().toString();
        String[] temp = s.split("x");
        initButon(Integer.parseInt(temp[0]));
        setWindowsSize(Integer.parseInt(temp[0]));

    }

    public void newGame() {
        if (isGameStart) {
            t.stop();
            int confirm = JOptionPane.showConfirmDialog(null, "Do you must"
                    + " be want to make new game?", "New Game", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                this.init();
            } else if (confirm == JOptionPane.NO_OPTION) {
                t.start();
            }
        } else {
            this.init();
        }

    }

}
